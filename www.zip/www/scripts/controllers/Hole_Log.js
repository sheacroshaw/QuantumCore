'use strict';

angular.module('quantumRApp')
  .controller('HoleLogCtrl', function ($scope) {
    $scope.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
