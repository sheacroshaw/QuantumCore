'use strict';

angular.module('quantumRApp')
  .controller('PreShiftCtrl', ['$scope','Appdata',function ($scope,Appdata) {
    
  }]);
