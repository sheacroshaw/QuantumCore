'use strict';

angular.module('quantumRApp')
  .controller('MainCtrl', function ($scope) {


	
  });
