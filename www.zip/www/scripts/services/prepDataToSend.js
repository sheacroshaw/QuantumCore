'use strict';

angular.module('quantumRApp')
  .service('Prepdatatosend', [function prepDataToSend () {
  	
	    
  }]);
